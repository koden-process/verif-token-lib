import os

KEYCLOAK_URL = os.environ['KEYCLOAK_URL']
API_NAME = os.environ['API_NAME']
